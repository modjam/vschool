module.exports = {
  "secret": "Hello all"
};
